# Terry React UI Library

Reusable React/TypeScript UI components with a shared base visual system.

The repository has two explicit products:

- **Library package** — built with Vite library mode into `dist/`, including ESM JavaScript, TypeScript declarations and bundled CSS.
- **Showcase site** — built separately into `site-dist/` and deployed to GitHub Pages.

## Install / consume

The package can be consumed from GitHub or, later, from a package registry. React is a peer dependency, so the host application owns the React runtime.

```ts
import {
  BoolSwitch,
  Button,
  Dialog,
  EntityHeader,
  MultiSelect,
  SegmentedControl,
  SlidingTabs,
  Select,
  Slider,
  TextField,
} from "terry-react-ui-library";
```

The generated `dist/index.js` imports `dist/style.css`, so consumers keep the one-import experience. `terry-react-ui-library/style.css` is also exported for hosts that prefer an explicit stylesheet import.

## Package layout

```text
src/
  index.ts                 public source entry
  components/              canonical component implementations
    BoolSwitch/
      BoolSwitch.tsx
      index.ts
    Select/
      Select.tsx
      index.ts
    SegmentedControl/
      SegmentedControl.tsx
      index.ts
    SlidingTabs/
      SlidingTabs.tsx
      index.ts
    TextField/
    Slider/
    Dialog/
    Button/
    EntityHeader/
    MultiSelect/
    ...
  visual-icons/            reusable icon-generation system
    index.ts               resolver registry + public exports
    tileIcons.ts           coordinate/sprite-sheet crop generator
    semanticIcons.tsx      Lucide/open-source semantic icons
    simpleIcons.tsx        element + text / text-card icons
    visual-icons.css       shared icon presentation
  styles/base/             base theme, motion and component visual CSS
    register.ts            single base-style registration entry
scripts/
  finalize-library.mjs     verifies/finalizes dist CSS and base-style assets
vite.config.lib.ts         library build
vite.config.ts             showcase build
tsconfig.lib.json          declaration build

dist/                      generated package artifact (not committed)
site-dist/                 generated showcase artifact (not committed)
```

`src/components/` is the public module boundary and the canonical implementation location. The files under `src/styles/base/` own the shared visual styling rather than product-specific behavior.

## Shared tab controls

The library deliberately exposes two different controls instead of forcing one visual language into every context.

### SegmentedControl

`SegmentedControl` is the equal-width pill group for **high-level mode or view switching**.

- A group is intended for two or more labels.
- Every item in the same group has equal width.
- Items touch with no gap.
- The outer left and right ends are fully rounded like a capsule; internal shared edges stay square.
- The selected item does **not** use an underline. Its surface becomes slightly brighter and its text/icon changes to `--tc-accent`.
- Use it where the current mode deserves a stronger visual container, such as User / AI or Visual / Text.

### SlidingTabs

`SlidingTabs` is the borderless compact control for **dense parameter groups**.

- No rounded outer shell and no item borders.
- A muted track remains visible below the whole group.
- The accent indicator slides under the active item.
- Active text/icon uses `--tc-accent`.
- Items share equal width.
- Prefer it for dense settings such as resolution, quality, generation mode and context mode.

Products should reuse these controls according to semantic density rather than recreate local tag/tab styles.

## Showcase requirement

The Showcase is part of the library contract, not optional documentation.

- Every new exported public UI component must be added to `index.html` in the **same change** that introduces the component.
- New component states that materially affect appearance or interaction should also be visible in the Showcase.
- A component is not considered finished until it can be inspected on the Showcase with the current Base Style theme.

## Visual icon module

The UI library owns the reusable icon engine. Product repositories should only provide product-specific asset coordinates or semantic mappings; they should not duplicate the rendering implementation.

The module intentionally supports three generation paths:

1. **Tile / sprite icons** — `createTileIconStyle()` crops a coordinate cell from a shared image sheet and scales it to the requested display size.
2. **Open-source semantic icons** — `SemanticIcon` / `createOpenIcon()` render the library's Lucide-backed semantic icon set.
3. **Simple element + text icons** — `SimpleIcon` / `createSimpleIcon()` provide compact rounded text cards, optionally with a semantic element icon.

`installOptionIconResolver()` lets a host application register its own value-to-icon mapping once. `Select` and `MultiSelect` consume that resolver automatically when an option does not provide an explicit `icon` node.

## Build

```bash
npm run typecheck
npm run build:lib
npm run build:showcase
npm run build
```

`npm run build:lib` produces and verifies:

```text
dist/
  index.js
  index.d.ts
  style.css
  base/
    theme.css
    theme-system.css
```

A Git dependency runs `prepare`, so consumers receive the generated `dist` package rather than compiling raw TypeScript source themselves.

## Dependency contract

- `react` and `react-dom` are **peerDependencies**. The consuming application owns the React runtime.
- `lucide-react` remains a normal runtime dependency because components and the visual-icon module use its icons internally.
- The package export map points consumers at `dist`, not `src`.
- CSS is marked as a side effect so bundlers must not tree-shake component styling away.
- CI installs the current Git SHA into a clean temporary Vite consumer and builds it; this protects the same install path used by Rulesmd Editor.

## Theme / style ownership

The base style exposes its visual color system through CSS variables. Component React code owns behavior and semantic DOM; the base style owns the visual CSS. Consumers should customize public variables rather than targeting component internals.

Primary public channels include:

- `--tc-base`
- `--tc-accent`
- `--tc-effect`
- `--tc-text-main`
- `--tc-text-bright`

The single style registration entry is `src/styles/base/register.ts`. New shared component CSS must be registered through the base style instead of being imported ad hoc by arbitrary component files.

## Component boundary rules

- Product CSS must not reach into component implementation DOM to correct geometry.
- Components own their internal margin, padding, line-height, track/knob geometry and motion.
- Consumers may size and place documented outer hosts / public props only.
- A component bug must be fixed here and verified in the showcase before a product adds a workaround.
- Broad consumer selectors such as `.panel span`, `.row button` or `.dialog input` are unsafe around shared components.
- Stateful icon rules must target the icon role itself. Selectors such as `.is-open svg`, `.is-active svg`, or `.control:hover svg` are forbidden because they also mutate nested action/check/status icons. Scope transforms to the trigger icon or an explicit icon class.
- New component behavior belongs under `src/components/<Component>/`; reusable icon generation belongs under `src/visual-icons/`; new visual rules belong in the base style or the visual-icon module stylesheet.
- New exported public components must be shown on the Showcase in the same change.

The BoolSwitch / Select cascade incident in Rulesmd Editor is the reference red-line case for these rules. The inverted MultiSelect checkmark caused by an open-state descendant `svg` transform is the corresponding icon-scope red-line case.

## Compatibility

Package consumers use the standard `dist` export map. Existing component names and public props are intentionally preserved.